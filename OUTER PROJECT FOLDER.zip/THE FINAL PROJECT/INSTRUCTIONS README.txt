Instructions on how to use AirNow
=================================

Note: Only to be used on Windows 10 operating system
====================================================

NOTE: DO NOT CHANGE THE LOCATION OF ANY FILE/FOLDER IN THIS FOLDER, ALL FILES/FOLDERS MUST REMAIN UNDER THIS FOLDER(THE FINAL PROJECT)
=============================================================================================================================

1. Select a specific python interpreter(Eg: Python 3.8.4, Python 3.8.2, Python 3.7.4) NOTE: PYTHON 3.8.4 RECOMMENDED

2. install tkcalendar using pip on command prompt. (pip install tkcalendar) or (python -m pip install tkcalendar)

3. install Pillow using pip on command prompt. (pip install Pillow) or (python -m pip install Pillow)

4. install mysql.connector using pip on command prompt. (pip install mysql-connector-python) or (python -m pip install mysql-connector-python)

5. Open AirNow (FINAL PROJECT).py file using the IDLE Python editor for the python version where the above 3 modules are installed

6. Run the code
